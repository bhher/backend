package mini.chelsea;

public class ChelseaNews {
    public void showNews() {
        System.out.println("Chelsea FC 뉴스");

    }
}

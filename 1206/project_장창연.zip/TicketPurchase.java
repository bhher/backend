package mini.chelsea;

public class TicketPurchase {
    public void purchaseTicket() {
        System.out.println("티켓 구매");
    }
}


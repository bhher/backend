package a1127.aniSystem;

import java.util.Scanner;

public class AniSys {
 
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Animal animal = null;
        Animal[] animals = new Animal[3];

        String name;
        int age;
        int index = 0;
        while (true) {
            System.out.print("1.개 2.물고기 3.새 >>");
            String input = scan.nextLine();

            if(index == 3){return;}
            if(input == "1"){
                System.out.print("이름");
                name = scan.nextLine();
                System.out.print("나이");
                age = scan.nextInt();

                animals[index++] = new Dog(name,age);
            }
            else if(input == "2"){
                System.out.print("이름");
                name = scan.nextLine();
                System.out.print("나이");
                age = scan.nextInt();

                animals[index++] = new Fish(name,age);
            }
            else if(input == "3"){
                System.out.print("이름");
                name = scan.nextLine();
                System.out.print("나이");
                age = scan.nextInt();

                animals[index++] = new Bird(name,age);
            }else{return;}
        
        }
        for(Animal animal : animals){

        }
        



    }
}

package a1127.aniSystem;

public abstract class Animal {


    abstract void sound();
    abstract void move();
}

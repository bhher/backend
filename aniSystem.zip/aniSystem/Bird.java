package a1127.aniSystem;

public class Bird extends Animal{
    public Bird(){};

    @Override
    void move() {
        System.out.println("날개로 날아간다.");
    }
}

package a1127.aniSystem;

public class Dog extends Animal{

    String name;
    int age;
    
    public Dog(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public Dog() {
    }

    @Override
    void move() {
        System.out.println("네 발로 걷는다");
        
    }

    @Override
    void sound() {
        System.out.println("멍멍");
        
    }

    
}

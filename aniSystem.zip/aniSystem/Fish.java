package a1127.aniSystem;

public class Fish extends Animal {
    public Fish(){}

    @Override
    void move() {
        System.out.println("지느러미를 이용해 헤엄친다.");
        
    }

    @Override
    void sound() {
        System.out.println("...");
        
    };
    
    
}

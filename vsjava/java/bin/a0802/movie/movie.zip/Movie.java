package a0802.movie;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Movie {
    private long id;
    private String title; // 영화 제목
    private String genre; // 영화 장르
    private static final File file = new File("C:\\junsuk\\vscode_java\\Hello\\src\\movies.txt");
    public Movie(long id, String title, String genre) {
        this.id = id;
        this.title = title;
        this.genre = genre;
    }

    public static ArrayList<Movie> findAll() throws IOException{
        ArrayList<Movie> movies = new ArrayList<Movie>();
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line = null;
        while ((line = br.readLine()) != null) {//팡리을 한 행씩 읽어와 반복
            String [] temp = line.split(",");
            Movie m = new Movie(
                Long.parseLong(temp[0]), //영화대표값
                temp[1], // 영화 제목
                temp[2] // 영화 장르
            );
            movies.add(m);// 생성 영화 객체를 ArrayList에 추가
        }
        br.close(); // 파일 입력 흐름 해제
        return movies; // 영화 객체가 담긴 ArrayList 반환
    }

}

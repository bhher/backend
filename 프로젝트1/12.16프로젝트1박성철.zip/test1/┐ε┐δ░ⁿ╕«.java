package test1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

public class 운용관리 {
    
    private static ArrayList<기본골자> 기본내용;
    private static ArrayList<고객정보> 정보;

    private static Map<String, 기본골자> 빠른확인용 = new HashMap<>();


    private static 파일 예약내용저장용 = new 파일();
    Scanner sc = new Scanner(System.in);

    public 운용관리(){

        기본내용 = new ArrayList<>();

        기본내용.add(new 기본골자("1경기", "15:00", 50000));
        기본내용.add(new 기본골자("2경기", "19:00", 60000));
        기본내용.add(new 기본골자("3경기", "21:00", 60000));

        정보 = new ArrayList<>();
        기본골자 선택경기 = 기본내용.get(0);
        빠른확인용.put("test", 선택경기);



    }


    
    public String 경기예매출력 = "경기 예매 화면입니다.";









    public void 좌석목록메서드(String str11) {
        System.out.println("================== " + str11 + " ==================");
        int count =1;

        for(기본골자 gi2 : 기본내용){
            System.out.println(count+ "" +gi2.toString()); 
            count++;
        }
        System.out.println("===============================================");

        메뉴처리();

    }
    public void 좌석목록메서드2(String str11) {
        System.out.println("================== " + str11 + " ==================");
        int count =1;

        for(기본골자 gi2 : 기본내용){
            System.out.println(count+ "" +gi2.toString2()); 
            count++;
        }
        System.out.println("===============================================");
    }











    public void 좌석예메메서드() {
        for(;;){ // 무한루프를 시키는 거임.
            좌석목록메서드2("좌석 예매"); // 괄호 임의로 작성함
            System.out.print("예매할 경기를 입력해주세요 >> ");
        
            try {
                int 숫자확인 = Integer.parseInt(sc.next());
                if (숫자확인 > 기본내용.size() || 숫자확인 < 1) { // 경기가 3개 밖에 없으니까
                    //예약할 수 있는 목록의 갯수?보다 크거나 목록이 없으면 (여기서 ㄹㅇ 끝남)
                    System.out.println("잘못된 입력입니다");
                    continue; // 잘못 입력했으면 되돌리려고.(루프시킴)
                }


                System.out.println("선택한 경기");
                System.out.println("===============================================");
                System.out.println(숫자확인 + "" + 기본내용.get(숫자확인 - 1));
                System.out.println("===============================================");

                기본골자 선택경기 = 기본내용.get(숫자확인 - 1); //선택한 경기를 선택경기에 저장한다

                if (경기좌석현황확인메서드(선택경기)) {  // 좌석이 모두 예약되었는지 확인
                    System.out.println("죄송합니다. 해당 경기의 좌석은 모두 예약되었습니다.");
                    continue; // 다시 선택하도록 안내
                }


               
                예약자정보메서드(선택경기);
                String 좌석번호 = Integer.toString(좌석선택메서드(선택경기)); // 좌석을 넣을 메서드
                정보.get(정보.size()-1).set지정좌석(좌석번호);
                System.out.println("예약 중 입니다.");
                

                System.out.println("===============================================");
                System.out.println("예약에 성공했습니다.");
                System.out.println("[ " + 정보.get(정보.size()-1).get고객이름() + " ] 님의 예약정보");
                System.out.println(숫자확인 + "" + 선택경기);
                System.out.println("===============================================");

                System.out.println("메인 화면으로 이동합니다.");
                빠른확인용.put(정보.get(정보.size()-1).get고객이름(),선택경기);
                break;


            } catch (NumberFormatException e) {//숫자가 아닐 경우 처리하는 에러코드메서드
                System.out.println("잘못된 입력입니다.");
            }

        }
    }

















    private boolean 경기좌석현황확인메서드(기본골자 sf) {
        // 항공편의 좌석 배열에서 모든 좌석이 'XX'로 예약되었는지 확인
        for (String seat : sf.get좌석()) {
            if (!seat.equals("XX")) {
                return false; // 하나라도 비어있는 좌석이 있으면 예약 가능
        }
        }
        return true; // 모든 좌석이 'XX'로 예약되었으면 예약 불가

    }













    public void 메뉴처리() {
        while (true) {
            System.out.println("1. 되돌아가기\n2. 예매하기\n메뉴입력>");
            
            String 선택 = sc.next();
            sc.nextLine(); //버퍼 비우기
            
            int 선택번호 = -1;
            
            try {
                선택번호 = Integer.parseInt(선택);
            } catch (NumberFormatException e) {
                선택번호 = 9;
            }
    
            switch (선택번호) {
                case 1:
                    return; // 메서드를 종료하고 다시 메뉴
                case 2:
                    System.out.println("경기 및 좌석 예메로 이동합니다.");
                    좌석예메메서드();
                    break;
                default:
                    System.out.println("잘못된 입력입니다. 다시 선택해주세요.");
                    break;
            }
        }
    }






    private void 예약자정보메서드(기본골자 f3) {
        System.out.println("예매자 정보를 입력하세요");
        System.out.print("이름: ");
        String name = sc.next();
        System.out.printf("생년월일(6자리):");
        int birthDate = Integer.parseInt(sc.next());


        고객정보 p = new 고객정보(name, birthDate); // 두개짜리 세개짜리 생성자 만들었던 거
    
        System.out.print("결제 비밀 번호를 입력하세요: ");
        String pw = sc.next();
        p = new 고객정보(name, birthDate, pw); // 이 3가지가 모두 있는 것 만이
        정보.add(p);

    }





    private int 좌석선택메서드(기본골자 좌석용변수) {
        int 자리확인용 = -1;
        while (true) {
            try {
                System.out.println("========================================");
                좌석용변수.좌석ToString(); // 전체 좌석 출력 (1번부터 40번까지)
                System.out.println("[A] 응원석 (1번~20번 좌석), [B] 응원석 (21번~40번 좌석) 중 하나를 선택하세요.");
                System.out.print("선택> ");
                String 그룹선택 = sc.nextLine(); // 사용자로부터 응원석 그룹 선택
    
                // A 또는 B 응원석 그룹 선택 확인
                if (!그룹선택.equalsIgnoreCase("A") && !그룹선택.equalsIgnoreCase("B")) {
                    System.out.println("잘못된 응원석 선택입니다.");
                    continue;
                }
    
                // 선택된 응원석 그룹에 맞게 좌석 표시
                System.out.println("========================================");
                if (그룹선택.equalsIgnoreCase("A")) {
                    showSeatsForGroupA(좌석용변수);  // [A] 응원석 좌석 표시 (1~20번)
                } else {
                    showSeatsForGroupB(좌석용변수);  // [B] 응원석 좌석 표시 (21~40번)
                }
    
                System.out.print("예매하실 좌석 번호를 선택하세요: ");
                int seatInt = sc.nextInt() - 1;
                sc.nextLine();
    
                if (seatInt < 0 || seatInt >= 40) {
                    System.out.println("존재하지 않는 좌석입니다.");
                    continue;
                }
    
                // 좌석 예약 (A 응원석은 0~19, B 응원석은 20~39)
                if (그룹선택.equalsIgnoreCase("A") && seatInt >= 20) {
                    System.out.println("A 응원석은 1번~20번 좌석만 선택 가능합니다.");
                    continue;
                } else if (그룹선택.equalsIgnoreCase("B") && seatInt < 20) {
                    System.out.println("B 응원석은 21번~40번 좌석만 선택 가능합니다.");
                    continue;
                }
    
                if (좌석용변수.get좌석().get(seatInt).equals("XX")) {
                    System.out.println("이미 예약된 좌석입니다.");
                } else {
                    좌석용변수.get좌석().set(seatInt, "XX"); // 좌석 예약
                    System.out.println("좌석 선택이 완료되었습니다.");
                    자리확인용 = seatInt;
                    break;
                }
    
            } catch (InputMismatchException e) {
                System.out.println("잘못 입력하셨습니다.");
                sc.nextLine();
            }
        }
        return 자리확인용;
    }
    

    
    // A 응원석 (1번~20번 좌석)
    private void showSeatsForGroupA(기본골자 f1) {
        System.out.println("[A] 응원석: 1번~20번 좌석");
        for (int i = 0; i < 20; i++) {
            System.out.printf(" [%2s] ", f1.get좌석().get(i)); // 1번부터 20번까지 표시
            if (i % 5 == 4) { // 5개마다 줄바꿈
                System.out.println();
            }
        }
        System.out.println();
        System.out.println("--------------------------------------");
    }

    // B 응원석 (21번~40번 좌석)
    private void showSeatsForGroupB(기본골자 f2) {
        System.out.println("[B] 응원석: 21번~40번 좌석");
        for (int i = 20; i < 40; i++) {
            System.out.printf(" [%2s] ", f2.get좌석().get(i)); // 21번부터 40번까지 표시
            if (i % 5 == 4) { // 5개마다 줄바꿈
                System.out.println();
            }
        }
        System.out.println();
        System.out.println("--------------------------------------");
    }


















    public void 좌석예약조회메서드() {//예약확인
        int index = 탐색("예약 확인"); // // [4-2-7]
        checkPassword(index); // // [4-2-8]
    }

    private int 탐색(String str) {//이름을 검색받아서 인텍스 번호 반환
        System.out.println("===================== " + str + " =====================");
        System.out.print("예약자 이름: ");
        String name = sc.next();
        sc.nextLine();

        int index = -1;
        if(정보 != null){
            for (int i=0; i < 정보.size(); i++){
                if(정보.get(i).get고객이름().equals(name)){
                    index = i;
                }
            }
        }
        return index;
    }

 
    private void checkPassword(int index) {
    for(;;){
        if(index !=-1){
            System.out.print("결제 비밀번호: ");
            String pw = sc.next();
            System.out.println();
            if(정보.get(index).get비밀번호().equals(pw)){
                System.out.println("비밀번호가 일치합니다.");
                System.out.println(ticketPrint(빠른확인용, 정보.get(index).get고객이름()));
                break;
            }else{
                System.out.println("비밀번호가 일치하지 않습니다.");
            }

        }else{
            System.out.println("일치하는 이름이 없습니다.");
            break;
        }

    }

    }

    String ticketPrint(Map<String, 기본골자> HMap, String name) {
        int index = -1;
        if(정보 !=null){
            for(int i=0; i < 정보.size();i++){
                if(정보.get(i).get고객이름().equals(name)){
                    index = i;
                }
            }
        }
        int seat = Integer.parseInt(정보.get(index).get지정좌석())+1;
        return  "ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ\n\n" +
                "\t" + name + "님의 티켓정보" +
                "| 좌석 : " + seat + "번\n"+
                "." + HMap.get(name) + "\n\n" +
                "ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ";
    }












    public void ticketSave() {
        int index = 탐색("티켓 조회");
        checkPassword(index);
        예약내용저장용.ticketSaveFile(빠른확인용, 정보.get(index).get고객이름());

    }

    public static ArrayList<기본골자> getFlights() {
        return 기본내용;
    }


    public static Map<String, 기본골자> getReservationMap() {
        return 빠른확인용;
    }


}

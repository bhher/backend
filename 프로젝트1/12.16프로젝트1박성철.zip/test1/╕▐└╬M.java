package test1;

import java.util.Scanner;

public class 메인M {
    public static void main(String[] args) {
        운용관리 운용관리객체 = new 운용관리();
        Scanner sc = new Scanner(System.in);
        파일 파일객체 = new 파일();

        System.out.println("==============================");
        System.out.println(운용관리객체.경기예매출력);
        System.out.println("==============================");



        while (true) {
            System.out.println(" 1. 좌석 목록 \n 2. 좌석 예매 \n 3. 좌석 예약 조회 \n 4. 티켓 저장 \n 5. 좌석 현황 업로드 \n 0. 종료 \n");
            System.out.print("메뉴입력>");

            String 메뉴이동번호저장객체 = sc.next();
            sc.nextLine(); //버퍼 비우기 개행문자였나
        
            int 잘못된값확인용 = -1;


            try {
                잘못된값확인용 = Integer.parseInt(메뉴이동번호저장객체);
            } catch (NumberFormatException e) {
                잘못된값확인용 = 9;
            }

            switch (잘못된값확인용) {
                case 1:
                    운용관리객체.좌석목록메서드("좌석확인");
                    break;
                case 2:
                    운용관리객체.좌석예메메서드();
                    break;
                case 3:
                    운용관리객체.좌석예약조회메서드();
                    break;
                case 4:// 티켓을 파일로 저장
                    운용관리객체.ticketSave();
                    break;
                case 5: //항공편 업로드 -> 항공편 불러오기
                    파일객체.upload();
                    break;  




                case 0:
                    System.out.println("프로그램을 종료합니다.");
                    sc.close();
                    break; 
                    //   Outter(지정한 위치) 로 빠져 나감 
                default:
                    System.out.println("잘못된 입력입니다.");
                    break;
            }
            
        }


    }
}

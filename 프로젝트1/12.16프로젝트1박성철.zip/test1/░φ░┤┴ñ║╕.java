package test1;

public class 고객정보 {
    
    private String 고객이름;
    private int 생년월일;
    private String 비밀번호;
    private String 지정좌석;


    public 고객정보(String 고객이름, int 생년월일) {
        this.고객이름 = 고객이름;
        this.생년월일 = 생년월일;
    }


    public 고객정보(String 고객이름, int 생년월일, String 비밀번호) {
        this.고객이름 = 고객이름;
        this.생년월일 = 생년월일;
        this.비밀번호 = 비밀번호;
    }


    
    public String get고객이름() {
        return 고객이름;
    }
    public void set고객이름(String 고객이름) {
        this.고객이름 = 고객이름;
    }
    public int get생년월일() {
        return 생년월일;
    }
    public void set생년월일(int 생년월일) {
        this.생년월일 = 생년월일;
    }

    public String get비밀번호() {
        return 비밀번호;
    }
    public void set비밀번호(String 비밀번호) {
        this.비밀번호 = 비밀번호;
    }
    public String get지정좌석() {
        return 지정좌석;
    }
    public void set지정좌석(String 지정좌석) {
        this.지정좌석 = 지정좌석;
    }


}

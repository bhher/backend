package test1;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class 기본골자 {
    //필드를 만듬.
    private String 어떤경기;
    private String 시간;
    private int 가격;
    private DecimalFormat 숫자정렬 = new DecimalFormat("#.###원");
    private ArrayList<String> 좌석;



    // 기본 생성자 일단 혹시 몰라서 만들어 둠.
    public 기본골자() {
    }

    // 생성자 만듬듬
    public 기본골자(String 어떤경기, String 시간, int 가격) {  // , ArrayList<String> 좌석 제거함 
        this.어떤경기 = 어떤경기;
        this.시간 = 시간;
        this.가격 = 가격;
        좌석 = new ArrayList<>();
        for(int i=1; i<=40; i++){
            좌석.add(String.valueOf(i));
        }
    }
//     for (int i = 1; i <= 40; i++) {
//         좌석.add("  ");  // 초기에는 모두 빈 좌석으로 설정
//     }
// }



    //getter setter 만듬
    public String get어떤경기() {
        return 어떤경기;
    }
    public void set어떤경기(String 어떤경기) {
        this.어떤경기 = 어떤경기;
    }
    public String get시간() {
        return 시간;
    }
    public void set시간(String 시간) {
        this.시간 = 시간;
    }
    public int get가격() {
        return 가격;
    }
    public void set가격(int 가격) {
        this.가격 = 가격;
    }
    public DecimalFormat get숫자정렬() {
        return 숫자정렬;
    }
    public void set숫자정렬(DecimalFormat 숫자정렬) {
        this.숫자정렬 = 숫자정렬;
    }
    public ArrayList<String> get좌석() {
        return 좌석;
    }
    public void set좌석(ArrayList<String> 좌석) {
        this.좌석 = 좌석;
    }

    @Override
    public String toString() {
        String 돈정렬1 = 숫자정렬.format(가격);
        return " >> [경기 = " + 어떤경기 + ", 예약 시간=" + 시간 + ", 가격=" + 돈정렬1 +"]"; //+ ", 좌석=" + 좌석 +
    }


    public String toString2() {
        String 돈정렬1 = 숫자정렬.format(가격);
        return " >> [관람 가능 경기 = " + 어떤경기 + ", 예약 시간=" + 시간 + ", 가격=" + 돈정렬1 +"]"; //+ ", 좌석=" + 좌석 +
    }



    
    public void 좌석ToString() {
        System.out.println("전체 좌석:");

        // A 응원석 출력 (좌석 1번부터 20번까지)
        System.out.println("A 응원석:");
        for (int i = 0; i < 20; i++) {
            System.out.printf(" [%2s] ", 좌석.get(i)); // 좌석 상태 출력
            if (i % 5 == 4) { // 5개마다 줄바꿈
                System.out.println();
            }
        }

        // 구분선 출력
        System.out.println("--------------------------------\n");
        
        // "경기장 스크림" 출력
        System.out.println("      경 기 장  스 크 림");
        
        // 구분선 출력
        System.out.println("\n-------------------------------");
        System.out.println("        [B] 응원석");
        
        System.out.println("B 응원석:");
        for (int i = 20; i < 40; i++) {
            System.out.printf(" [%2s] ", 좌석.get(i)); // 좌석 상태 출력
            if (i % 5 == 4) { // 5개마다 줄바꿈
                System.out.println();
            }
        }
    }
}
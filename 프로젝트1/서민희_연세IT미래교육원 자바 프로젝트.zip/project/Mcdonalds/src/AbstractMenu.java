import java.util.Scanner;

abstract class AbstractMenu implements Menu {
    protected String[] menuText;
    protected static final Scanner sc = new Scanner(System.in);

    // 생성자에서 menuText를 초기화
    public AbstractMenu(String[] menuText) {
        this.menuText = menuText;  // menuText를 초기화
    }

    @Override
    public void print() {
        // MenuPrinter로부터 반환된 문자열을 출력
        System.out.println(MenuPrinter.printMenu(menuText));
    }
}

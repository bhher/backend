import java.io.*;

public class Cart {

    private McDTO menu;
    private int qt;

    private static final File file = new File("./Mcdonalds/src/data/Cart.txt");
    private static final File ordNoFile = new File("./Mcdonalds/src/data/OrderNo.txt");
    private static int ordNo = 1; // Default starting order number

    static {
        // Load the last order number from the file during initialization
        if (ordNoFile.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(ordNoFile))) {
                String line = br.readLine();
                if (line != null) {
                    ordNo = Integer.parseInt(line.trim());
                }
            } catch (IOException | NumberFormatException e) {
                System.err.println("Failed to load order number, starting from 1.");
            }
        }
    }

    public static int getNextOrdNo() {
        return ordNo++;
    }

    public static void saveOrdNo() {
        // Save the current order number to the file
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ordNoFile))) {
            bw.write(String.valueOf(ordNo));
        } catch (IOException e) {
            System.err.println("Failed to save order number.");
        }
    }

    public static File getFile() {
        return file;
    }

    public McDTO getMenu() {
        return menu;
    }

    public void setMenu(McDTO menu) {
        this.menu = menu;
    }

    public int getQt() {
        return qt;
    }

    public void setQt(int qt) {
        this.qt = qt;
    }

    public Cart(McDTO menu) {
        this.menu = menu;
        this.qt = 1;
    }

    // Add item to cart
    public void save() throws IOException {
        try (BufferedWriter fw = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(file, true), "UTF-8"))) {
            fw.write(this.toFileString() + "\n");
        }
    }

    // Increase quantity
    public void increaseQt() {
        this.qt++;
    }

    // Cart output
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        sb.append(MenuPrinter.printBoundaryTop(25));
        sb.append(String.format("│   " + menu.getPrdNo() + " │ " + menu.getMenu() + "     │  "
        + menu.getPrice() + "원 │ " + qt + "개 \n"));
        sb.append(MenuPrinter.printBoundaryBottom(25));
        return sb.toString();
    }

    private String toFileString() {
        return menu.getPrdNo() + "," + menu.getMenu() + "," + menu.getPrice() + "," + qt;
    }
}

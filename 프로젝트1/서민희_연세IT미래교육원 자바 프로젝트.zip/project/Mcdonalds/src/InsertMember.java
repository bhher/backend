import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class InsertMember {

    private int id;
    private String name;
    private String pw;

    private static final File file = new File("./Mcdonalds/src/data/members.txt");

    public InsertMember(String name, String pw) {
        this.id = getNextId(); // 자동 증가 ID
        this.name = name;
        this.pw = pw;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    @Override
    public String toString() {
        return id + ", " + name + ", " + pw;
    }

    // Save a single member to the file
    public void saveMember() throws IOException {
        try (BufferedWriter fw = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(file, true), "UTF-8"))) {
            fw.write(this.toString());
            fw.newLine();
            System.out.println("회원정보 저장 완료: " + this.toString());
        }
    }

    // Get next ID from file
    public static int getNextId() {
        int lastId = 0;

        if (file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                String lastLine = null;

                while ((line = br.readLine()) != null) {
                    lastLine = line;
                }

                if (lastLine != null) {
                    String[] parts = lastLine.split(",");
                    lastId = Integer.parseInt(parts[0].trim());
                }
            } catch (IOException | NumberFormatException e) {
                System.err.println("Failed to read the last ID: " + e.getMessage());
            }
        }

        return lastId + 1; // Return the next ID
    }

    // Load all members into a map for login
    public static Map<String, String> loadMembers() {
        Map<String, String> memberMap = new HashMap<>();

        if (file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 3) {
                        String username = parts[1].trim();
                        String password = parts[2].trim();
                        memberMap.put(username, password);
                    }
                }
            } catch (IOException e) {
                System.err.println("회원 정보 로드 중 오류 발생: " + e.getMessage());
            }
        }
        return memberMap;
    }

    // Login method
    public static boolean login(String username, String password) {
        Map<String, String> memberMap = loadMembers();

        if (memberMap.containsKey(username)) {
            if (memberMap.get(username).equals(password)) {
                System.out.println("로그인 성공! 환영합니다, " + username + "님.");
                return true;
            } else {
                System.out.println("비밀번호가 일치하지 않습니다.");
            }
        } else {
            System.out.println("아이디가 존재하지 않습니다.");
        }
        return false;
    }
}

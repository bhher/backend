import java.io.IOException;
import java.util.Scanner;

public class LoginTest {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    System.out.print("아이디>> ");
    String username = sc.nextLine();
    System.out.print("비밀번호>> ");
    String password = sc.nextLine();
    InsertMember.login(username, password);

    sc.close();
  }
}

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class McDTO {
    private int prdNo;
    private String menu;
    private int price;
    private boolean isLunch; // 맥런치 여부

    private static final File file = new File(
            "./Mcdonalds/src/data/menuList.txt");

    private static int currentHour = java.time.LocalDateTime.now().getHour();

    public boolean isLunch() {
        return isLunch;
    }

    public void setLunch(boolean isLunch) {
        this.isLunch = isLunch;
    }

    public String getMenu() {
        return menu;
    }

    public void setMenu(String menu) {
        this.menu = menu;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getPrdNo() {
        return prdNo;
    }

    public void setPrdNo(int prdNo) {
        this.prdNo = prdNo;
    }

    public McDTO() {
    }

    public McDTO(int prdNo, String menu, int price) {
        this.prdNo = prdNo;
        this.menu = menu;
        this.price = price;
        this.isLunch = isLunch;
    }

    public McDTO(int prdNo, String menu, int price, boolean isLunch) {
        this.prdNo = prdNo;
        this.menu = menu;
        this.price = price;
        this.isLunch = isLunch;
    }

    // 파일에서 메뉴 읽어오기
    public static ArrayList<McDTO> findAll() throws IOException {
        ArrayList<McDTO> menus = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "utf-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    int prdNo = Integer.parseInt(parts[0].trim());
                    String name = parts[1].trim();
                    int price = Integer.parseInt(parts[2].trim());
                    boolean isLunch = parts.length > 3 && "맥런치".equals(parts[3].trim());
                    menus.add(new McDTO(prdNo, name, price, isLunch));
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("파일을 찾을 수 없습니다: " + file);
        } catch (IOException e) {
            System.out.println("파일을 읽는 중 오류가 발생했습니다.");
            throw e;
        }
        return menus;
    }

    // 메뉴 출력
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append(MenuPrinter.printBoundaryTop(30));

        // 10시~14시 사이에 맥런치 메뉴를 제외
        if (isLunch && (currentHour < 10 || currentHour >= 14)) {
            return "";
        } else {
            if(isLunch){
                sb.append(String.format("│ %2d | %-10s | %5d원 │ 맥런치 |\n", prdNo, menu, price));
            }else{
                sb.append(String.format("│ %2d | %-10s | %5d원 │\n", prdNo, menu, price));
            }
        }
        sb.append(MenuPrinter.printBoundaryBottom(30));
        return sb.toString();
    }

    // 메뉴 탐색
    public static McDTO findByMenu(int menuName) throws IOException {
        McDTO menu = null;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "utf-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim(); // 공백 및 줄바꿈 제거
                if (line.isEmpty())
                    continue; // 빈 줄 무시

                String[] temp = line.split(",");
                if (temp.length < 3) {
                    System.out.println("잘못된 형식의 데이터: " + line);
                    continue;
                }

                int id = Integer.parseInt(temp[0].trim());
                String name = temp[1].trim();
                int price;

                try {
                    price = Integer.parseInt(temp[2].trim());
                } catch (NumberFormatException e) {
                    System.out.println("가격 형식 오류: " + temp[2]);
                    continue;
                }

                if (menuName == id) {
                    menu = new McDTO(id, name, price);
                    break;
                }
            }
            return menu;

        }
    }

}

public class Mcdonalds {
    public static void main(String[] args) {
        System.out.println("환영합니다 고객님");
        Timer.nowTime();

        Menu menu = MenuList.getInstance();

        while (menu != null) {
            menu.print();
            menu = menu.next();
        }

    }
}

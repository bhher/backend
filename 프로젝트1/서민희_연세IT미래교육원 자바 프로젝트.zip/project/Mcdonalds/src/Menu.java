public interface Menu {
    void print();
    Menu next();
}

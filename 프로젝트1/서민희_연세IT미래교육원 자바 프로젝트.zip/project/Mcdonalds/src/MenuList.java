import java.io.IOException;
import java.util.ArrayList;

public class MenuList extends AbstractMenu {

    private static final ArrayList<Cart> cart = new ArrayList<>();
    private static final MenuList instance = new MenuList();
    private static final ArrayList<InsertMember> members = new ArrayList<>();
    private InsertMember loggedInMember = null; // 로그인된 회원

    public static MenuList getInstance() {
        return instance;
    }

    // MenuList 클래스의 생성자에서 super(menuItems)를 호출
    public MenuList() {
        super(new String[] {
                "1 메뉴",
                "2 장바구니",
                "3 주문",
                "4 로그인",
                "5 회원가입"
        });
    }

    @Override
    public Menu next() {
        System.out.print("메뉴를 선택하세요>> ");
        int choice = sc.nextInt();
        sc.nextLine();

        switch (choice) {
            case 1:
                // 메뉴 주문
                FoodMenu();
                return this;
            case 2:
                // 장바구니 확인
                ShowCart();
                return this;
            case 3:
                // 주문
                OrderMenu();
                return this;
            case 4:
                // 로그인
                Login();
                return this;
            case 5:
                // 회원가입
                InsertMember();
                return this;
            default:
                return this;
        }
    }

    // 로그인 로직
    private void Login() {
        System.out.print("아이디를 입력하세요: ");
        String username = sc.nextLine();
        System.out.print("비밀번호를 입력하세요: ");
        String password = sc.nextLine();

        // 로그인 처리
        if (InsertMember.login(username, password)) {
            loggedInMember = new InsertMember(username, password); // 현재 로그인된 회원 저장
            System.out.println(username + "님, 로그인되었습니다.");
        } else {
            System.out.println("로그인 실패! 아이디나 비밀번호를 확인해주세요.");
        }
    }

    // 3번 주문
    private void OrderMenu() {
        ShowCart();
        System.out.println("주문하시겠습니까?(y/n)");
        String answer = sc.nextLine();

        if (answer.equals("y")) {
            try {
                int nextOrdNo = Order.getNextOrdNo();

                for (Cart c : cart) {
                    int finalPrice = c.getMenu().getPrice() * c.getQt();

                    // 회원이라면 10% 할인 적용
                    if (loggedInMember != null) {
                        finalPrice = (int) (finalPrice * 0.9); // 10% 할인
                        System.out.println("회원 할인 적용: " + c.getMenu().getMenu() + " -> " + finalPrice + "원");
                    }

                    // 주문 저장
                    Order order = new Order(nextOrdNo, c.getMenu().getPrdNo(), c.getMenu().getMenu(), finalPrice,
                            c.getQt());
                    order.save();
                }

                cart.clear();
                System.out.println("주문이 완료되었습니다!");
            } catch (IOException e) {
                System.err.println("주문 저장 중 오류 발생: " + e.getMessage());
            }
        } else {
            System.out.println("주문이 취소되었습니다. 메뉴로 돌아갑니다.");
        }
    }

    // 회원가입
    private void InsertMember() {
        System.out.println("회원가입");
        System.out.print("아이디>> ");
        String newId = sc.nextLine();
        System.out.print("비밀번호>> ");
        String newPw = sc.nextLine();

        // 회원 추가 및 저장
        InsertMember newMember = new InsertMember(newId, newPw);
        members.add(newMember);
        try {
            newMember.saveMember(); // 개별 회원 저장
            System.out.println("회원가입이 완료되었습니다!");
        } catch (IOException e) {
            System.out.println("회원 정보 저장 실패: " + e.getMessage());
        }
    }

    // 장바구니 확인
    private void ShowCart() {
        System.out.println("현재 장바구니");
        if (cart.isEmpty()) {
            System.out.println("장바구니가 비어있습니다.");
        }
        for (Cart c : cart) {
            System.out.println(c);
        }
    }

    // 2번 주문
    private void FoodMenu() {
        try {
            ArrayList<McDTO> menus = McDTO.findAll();
            for (McDTO menu : menus) {
                System.out.println(menu);
            }
            System.out.print("메뉴를 선택해주세요>> ");
            int choiceMenu = Integer.parseInt(sc.nextLine().trim());

            McDTO m = McDTO.findByMenu(choiceMenu);
            System.out.println(m + "\n을 장바구니에 넣으시겠습니까? (y/n)");

            String cartYes = sc.nextLine();
            if (cartYes.equals("y")) {
                boolean alReadyInCart = false;
                for (Cart c : cart) {
                    if (c.getMenu().getPrdNo() == m.getPrdNo()) {
                        c.increaseQt();
                        c.save();
                        System.out.println("기존 주문 내역을 업데이트 했습니다.");
                        alReadyInCart = true;
                        break;
                    }
                }

                if (!alReadyInCart) {
                    Cart c = new Cart(m);
                    cart.add(c);
                    c.save();
                    System.out.println("장바구니에 넣었습니다.");
                    System.out.println("현재 장바구니" + c);
                }

            } else {
                System.out.println("장바구니 넣기를 취소했습니다.");
            }
        } catch (Exception e) {
            System.out.println("파일 읽기 오류: " + e.getMessage());
        }
    }
}

public class MenuPrinter {
    public static String printMenu(String[] menuItems) {
        int maxLength = 0;
        // 메뉴의 최대 길이를 계산
        for (String item : menuItems) {
            if (item.length() > maxLength) {
                maxLength = item.length();
            }
        }

        StringBuilder sb = new StringBuilder();
        sb.append("**이용하실 서비스를 선택해주세요**\n");
        // 상단 경계선 출력
        sb.append(printBoundaryTop(maxLength));

        // 메뉴 출력
        for (String item : menuItems) {
            sb.append("    " + item + "\n");  // StringBuilder에 항목을 추가
        }

        // 하단 경계선 출력
        sb.append(printBoundaryBottom(maxLength));

        return sb.toString();  // 반환
    }

    public static String printBoundaryTop(int length) {
        StringBuilder sb = new StringBuilder();
        sb.append("┌");
        for (int i = 0; i < length + 2; i++) {
            sb.append("──");
        }
        sb.append("┐\n");
        return sb.toString();
    }
    public static String printBoundaryBottom(int length){
        StringBuilder sb = new StringBuilder();
        sb.append("└");
        for (int i = 0; i < length + 2; i++) {
            sb.append("──");
        }
        sb.append("┘");
        return sb.toString();
    }


    // /
    // 
    // 
    // 
}

import java.io.*;
import java.util.*;

public class Order {
    private int ordNo;
    private int prdNo;
    private String menu;
    private int price;
    private int qt;

    private static final File file = new File("./Mcdonalds/src/data/Order.txt");

    public Order(int ordNo, int prdNo, String menu, int price, int qt) {
        this.ordNo = ordNo;
        this.prdNo = prdNo;
        this.menu = menu;
        this.price = price;
        this.qt = qt;
    }

    // Getter and Setter
    public int getOrdNo() {
        return ordNo;
    }

    public void setOrdNo(int ordNo) {
        this.ordNo = ordNo;
    }

    public int getPrdNo() {
        return prdNo;
    }

    public void setPrdNo(int prdNo) {
        this.prdNo = prdNo;
    }

    public String getMenu() {
        return menu;
    }

    public void setMenu(String menu) {
        this.menu = menu;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getQt() {
        return qt;
    }

    public void setQt(int qt) {
        this.qt = qt;
    }

    @Override
    public String toString() {
        return ordNo + "," + prdNo + "," + menu + "," + price + "," + qt;
    }

    // Save the order to the file
    public void save() throws IOException {
        try (BufferedWriter bw = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(file, true), "UTF-8"))) {
            bw.write(this.toString() + "\n");
        }
    }

    // Get the next order number
    public static int getNextOrdNo() {
        int lastOrdNo = 0;

        // Check if file exists and read the last order number
        if (file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                String lastLine = null;

                // Read until the last line
                while ((line = br.readLine()) != null) {
                    lastLine = line;
                }

                // If the file is not empty, extract the ordNo from the last line
                if (lastLine != null) {
                    String[] parts = lastLine.split(",");
                    lastOrdNo = Integer.parseInt(parts[0]);
                }
            } catch (IOException | NumberFormatException e) {
                System.err.println("Failed to read the last order number: " + e.getMessage());
            }
        }

        // Return the next order number
        return lastOrdNo + 1;
    }
}

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Timer {
    public static void nowTime(){

        LocalDateTime  now = LocalDateTime.now();

        String formatedNow = now.format(DateTimeFormatter.ofPattern("현재 시각: yyyy년 MM월 dd일 HH시 mm분 ss초"));

        int hour = now.getHour();
        System.out.println(formatedNow);
        LunchTime(hour);
    }

    public static void LunchTime(int hour){
        if(hour >= 10 && hour < 14){
            System.out.println("★☆★☆★☆지금은 맥런치 타임★☆★☆★☆");
        }
    }

}

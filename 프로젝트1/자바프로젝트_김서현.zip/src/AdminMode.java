import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;


public class AdminMode {
    Scanner input = new Scanner(System.in);

    ReservationManager reservationManager;
    TimeTableManager timeTableManager;

    private String password = "020118";             // 관리자 비밀번호 생성

    public AdminMode(ReservationManager reservationManager, TimeTableManager timeTableManager) {
        this.reservationManager = reservationManager;
        this.timeTableManager = timeTableManager;
    }

    public void start() {

         try{
             System.out.print("관리자 비밀번호를 입력하세요. >> ");
             String inputPw = input.next();
             System.out.println("\n! 관리자모드에 접속되었습니다 !");
             while(true){
                 if (inputPw.equals(password)) {
                     System.out.println("================== AdminMenu.. =================");
                     System.out.println("1.예약조회       2.예약수정      3.예약상태변경");
                     System.out.println("4.예약시간추가    5.예약시간삭제     6.메인메뉴");
                     System.out.print(">> ");
                     int choice = input.nextInt();
                     switch (choice) {
                         case 1:
                             check();
                             break;
                         case 2:
                             update();
                             break;
                         case 3:
                             change();
                             break;
                         case 4:
                             addTime();
                             break;
                         case 5:
                             deleteTime();
                             break;
                         case 6:
                             return;
                         default:
                             System.out.println("유효한 숫자를 입력하세요! default ");
                     }
                 }else{
                     System.out.println("비밀번호 오류 ! 관리자 모드 진입 실패\n");
                     break;
                 }
            }
        }catch(InputMismatchException e){
             System.out.println("올바른 값을 입력하세요 !");
         }
    }


    private void check() {
        ArrayList<Reservation> reservations = reservationManager.getReservations();     // ReservationManager 클래스에 있는 reservations 리스트 가져오기
        if (reservations.isEmpty()){
            System.out.println("등록된 예약이 없습니다.");
        }else{
            for (Reservation r : reservations){
                System.out.println("예약자명: "+r.getName()+"\t연락처: "+r.getPhone()+"\t예약인원: "+r.getNumber()+"\t예약시간: "+r.getrTime().getTime());
            }
        }
    }

    private void update(){
        ArrayList<Reservation> reservations = reservationManager.getReservations();
        ArrayList<TimeTable> timeList = timeTableManager.getTimeList();
        boolean found = false;

        if(reservations.isEmpty()){
            System.out.println("수정할 예약자 명단이 없습니다.");
        }else{
            System.out.print("수정할 예약자명 >> ");
            String name = input.next();
            System.out.print("해당 예약자의 연락처 >> ");
            String phone = input.next();

            for(Reservation r : reservations){
                if(r.getName().equalsIgnoreCase(name)){
                    if(r.getPhone().equalsIgnoreCase(phone)){
                        System.out.print("수정할 예약 인원 >> ");
                        int number = input.nextInt();
                        input.nextLine();
                        r.setNumber(number);
                        System.out.print("수정할 시간 >> ");
                        int updateTime = input.nextInt();

                        // timeList에서 예약 가능 여부 확인 후 검사
                        for(int i=0; i<timeList.size(); i++){
                            if(timeList.get(updateTime-1).isAvailable()){    // 내가 선택한 시간이 예약 가능한 시간대이면
                                timeList.get(updateTime-1).setAvailable(false);    //  선택한 시간 예약 불가능으로 변경
                                r.getrTime().setAvailable(true);                   //  기존 시간 예약 가능으로 변경
                                r.setrTime(timeList.get(updateTime-1));            //  객체 정보 업데이트
                                found=true;
                                System.out.println(r.getName()+"님의 예약 정보가 정상적으로 변경되었습니다.");
                                System.out.println("예약시간: "+r.getrTime().getTime()+"\t예약 인원: "+r.getNumber());
                                break;
                            }
                        }
                        if(!found){
                            System.out.println("선택한 시간은 예약이 불가능합니다.");
                            return;
                        }
                        break;
                    }
                }
            }
            if(!found){
                System.out.println("입력하신 정보가 조회되지 않습니다.");
            }
        }
    }

    private void change() {  // 예약가능여부 변경하는 메소드
        ArrayList<TimeTable> timeList = timeTableManager.getTimeList();

        try{
            timeTableManager.printList();
            System.out.print("예약 상태를 변경할 시간을 선택하세요 >> ");
            int time = input.nextInt();

            if(time>0 && time<timeList.size()){
                if(timeList.get(time-1).isAvailable()){    // 선택한 시간의 예약상태가 O 이면(true)
                    timeList.get(time-1).setAvailable(false);      // X로 변경
                    System.out.println("예약 상태 변경 완료! 이제 "+timeList.get(time-1)+"시에 예약이 불가능합니다.");
                }
                else{
                    timeList.get(time-1).setAvailable(true);
                    System.out.println("예약 상태 변경 완료! 이제 "+timeList.get(time-1)+"시에 예약이 가능합니다.");
                }
            }
            else{
                System.out.println("1~"+timeList.size()+"사이의 숫자를 입력하세요");
            }
        }catch(InputMismatchException e){
            System.out.println("1~"+timeList.size()+"사이의 숫자를 입력하세요! 예외");
        }
    }


    private void addTime() {
        ArrayList<TimeTable> timeList = timeTableManager.getTimeList();

        while(true){
            System.out.print("추가할 시간 입력(예- 00:00) >> ");
            String time = input.next();
            String formatTime = "\\d{2}:\\d{2}";
            if (time.matches(formatTime) ) {     // 입력값이 형식에 맞으면
                for(TimeTable t:timeList){
                    if(t.getTime().equalsIgnoreCase(time)==false){
                        TimeTable newTime = new TimeTable(time);
                        timeList.add(newTime);
                        System.out.println("정상적으로 추가되었습니다.");
                        break;
                    }
                    else{
                        System.out.println("이미 존재하는 시간입니다.");
                        return;
                    }
                }
            }else{
                System.out.println("형식에 맞게 입력하세요 !");
                return;
            }
            break;
        }
    }

    private void deleteTime() {
        ArrayList<TimeTable> timeList = timeTableManager.getTimeList();
        boolean isRemoved = false;

        while(true){
            timeTableManager.printList();
            System.out.print("삭제할 시간 번호 입력 >> ");
            int time = input.nextInt();
            for(int i=0; i<timeList.size(); i++){
                if(i==time-1){
                    timeList.remove(time-1);       // 입력한 값과 매칭되는 시간 삭제
                    System.out.println("정상적으로 삭제되었습니다.");
                    isRemoved = true;
                    break;
                }
            }
            if(!isRemoved){
                System.out.println("입력한 시간을 찾을 수 없습니다.");
            }
            break;
        }
    }
}

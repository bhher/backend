
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        // TimeTableManager 생성
        TimeTableManager timeTableManager = new TimeTableManager();
        // ReservationManager 생성 및 연결
        ReservationManager rm = new ReservationManager(timeTableManager);

        AdminMode admin = new AdminMode(rm,timeTableManager);
        Scanner input = new Scanner(System.in);


        while (true) {
            System.out.println("===================== Restaurant ====================");
            System.out.println("1.예약  2.예약조회  3.예약취소  4.관리자모드  5.종료");
            System.out.println("=====================================================");

            System.out.print("무엇을 도와드릴까요? >> ");

            try {
                int choice = input.nextInt();
                switch (choice) {
                    case 1:
                        rm.reserve();
                        break;
                    case 2:
                        rm.checked();
                        break;
                    case 3:
                        rm.delete();
                        break;
                    case 4:
                        admin.start();
                        break;
                    case 5:
                        System.out.println("프로그램을 종료합니다.");
                        System.exit(0);
                    default:
                        System.out.println("유효한 숫자를 입력하세요!");
                        break;
                }
            }catch(InputMismatchException e){
                System.out.println("1~5 사이의 숫자를 입력하세요!");
                input.nextLine();
            }
        }
    }
}
import java.io.File;
import java.sql.Time;

public class Reservation {
    private String name;    // 이름
    private String phone;   // 연락처
    private int number;  // 인원 수
    private TimeTable rTime;  // 예약한 시간

    public Reservation(){};


//    private static final File file = new File("C:\\Users\\YONSAI\\Desktop\\java\\JavaProject\\Reservation1\\src\\reservation.txt");
//    private String toFileString() {
//    return String.format("%s,%15s,%5d",name, phone, number);
//}


    public TimeTable getrTime() {
        return rTime;
    }

    public void setrTime(TimeTable rTime) {
        this.rTime = rTime;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @Override
    public String toString() {
        return
                "예약자명: "+ name +
                "   연락처: " + phone +
                "\n예약인원: " + number +
                "   예약시간: " + rTime ;
    }

}

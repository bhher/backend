import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

public class ReservationManager {
    Scanner input= new Scanner(System.in);


    TimeTableManager timeTableManager; // TimeTableManager 참조
    ArrayList<Reservation> reservations = new ArrayList<>();
    ArrayList<TimeTable> timeList;    // 선언만 수행
    public ReservationManager(TimeTableManager timeTableManager) {
        this.timeTableManager = timeTableManager; // 생성자를 통해 전달받음
        this.timeList = timeTableManager.getTimeList();     // 여기서 초기화
        // 생성자를 통해 초기화되기 전에는 null 상태이므로 필드에서 선언만 하고 초기화는 생성자 내부로 옮겨야 함
    }

    public ArrayList<Reservation> getReservations() {
        return reservations;
    }

    // 예약하기
    public void reserve() {

        while (true) {
            Reservation reservation = new Reservation();        // 예약할때마다 새로운 객체 생성될 수 있도록 while문 안으로 이동 (덮어쓰기 방지)
            timeTableManager.printList();
            try {
                System.out.println("============ 예약하기 ============");
                while (true) {

                    reservation.setName(inputName());         // 이름 입력받기
                    reservation.setPhone(inputPhone());       // 연락처 입력받기
                    reservation.setNumber(inputNumber());      // 예약 인원 입력받기
//                    reservations.add(selectTime())    ;  // 예약 시간 선택

                    while(true) {
                        System.out.print("예약하려는 시간을 선택하세요 >> ");
                        String choiceStr = input.nextLine();
                        try {
                            int choice = Integer.parseInt(choiceStr);
                            if (choice < 0 || choice > 7) {
                                System.out.println("1~" + timeList.size() + " 사이의 숫자를 입력하세요!");

                            } else {
                                for (int i = 0; i < timeList.size(); i++) {
                                    if (i + 1 == choice) {
                                        if (timeList.get(i).isAvailable()) {          // 예약 가능하면
                                            timeList.get(choice - 1).setTable(timeList.get(choice - 1).getTable() - 1);   // 예약 가능한 테이블 수 -1 하고
                                            if (timeList.get(choice - 1).getTable() == 0) {
                                                timeList.get(choice - 1).setAvailable(false);       // 예약 불가능으로 변경
                                            }
                                            reservation.setrTime(timeList.get(i));
                                            System.out.println(timeList.get(i).getTime() + "에 예약이 확정되었습니다.\n");
                                            reservations.add(reservation);
                                            return;
                                        } else {
                                            System.out.println("선택하신 타임은 예약이 불가능합니다.");
                                        }
                                    }
                                }
                            }
                        }catch(NumberFormatException e){
                            System.out.println("1~" + timeList.size() + " 사이의 숫자를 입력하세요!");
                        }
                    }
                }
            }catch(InputMismatchException e){
            System.out.println("올바른 숫자를 입력하세요!");}
        }
    }

    // 예약조회
    public void checked( ){
        boolean found = false;     // 검색 결과 추적
        System.out.println("============ 예약조회 ============");
        try{
            String name = inputName();
            String phone = inputPhone();

            for(Reservation r : reservations){
                if(r.getName().equalsIgnoreCase(name)){      // 예약자 명단 reservations에 입력값과 동일한 이름이 있으면
                    if(r.getPhone().equals(phone)){          // 번호까지 일치하는지 확인
                        found=true;
                        System.out.println(name+"님의 예약 현황");
                        System.out.println(r.getrTime().getTime()+"시에 "+r.getNumber()+"명 예약되었습니다.");
                        break;
                    }
                    else{
                        System.out.println("핸드폰 번호가 올바르지 않습니다.");
                        return;
                    }
                }
            }
            if(!found){
                System.out.println("예약자 명단에 없습니다.");
            }
        }catch(InputMismatchException e){
            System.out.println("올바른 값을 입력하세요.");
        }
    }

    // 예약취소
    public void delete() {
        boolean found = false;
        if (reservations.isEmpty()) {
            System.out.println("등록된 예약이 없습니다.");
        } else {
            String name = inputName();
            for (int i = 0; i < reservations.size(); i++) {
                Reservation r = reservations.get(i);
                if (r.getName().equalsIgnoreCase(name)) {
                    String phone = inputPhone();
                    if (r.getPhone().equals(phone)) {
                        reservations.remove(i); // 인덱스로 삭제
                        System.out.println("삭제 완료");
                        found = true;
                        break;
                    }
                }
            }
        }
        if (!found) {
            System.out.println("예약자 정보를 찾을 수 없습니다.");
        }
    }




    // 예약자 이름 입력
    private String inputName(){
        System.out.print("예약자명 입력 >> ");
        String name = input.nextLine();
        return name;
    }

    // 예약자 연락처 입력
    private String inputPhone(){
        while (true) {
            System.out.print("예약자 연락처 입력(ex. 010-0000-0000) >> ");
            String phone = input.nextLine();
            if (phone.matches("\\d{3}-\\d{4}-\\d{4}")) {
                return phone;
            } else {
                System.out.println("형식에 맞게 다시 입력하세요!");
            }
        }
    }

    // 예약 인원 입력
    private int inputNumber() {
        while (true) {
            System.out.print("예약 인원 입력 >> ");
            String numberStr = input.nextLine();

            try {
                int number = Integer.parseInt(numberStr);
                if (number >= 7) {
                    System.out.println("저희 레스토랑은 단체석이 준비되어있지 않아, 최대 6인까지만 식사가 가능합니다.");
                } else if (number < 0) {
                    System.out.println("예약 가능한 인원은 최소 1명입니다.");
                } else return number;
            } catch (NumberFormatException e) {
                System.out.println("올바른 숫자를 입력하세요! ");
            }
        }
    }

//    // 예약 시간 선택
//    private Reservation selectTime(){
//
//    }
}


import java.util.ArrayList;

public class TimeTable {

    private String time;
    private boolean available;
    private int table;


    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public int getTable() {
        return table;
    }

    public void setTable(int table) {
        this.table = table;
    }

    public TimeTable(String time) {
        this.time = time;
        this.available = true;
        this.table= 2;
    }


    @Override
    public String toString() {
        return
                "시간: " + time +
                "   예약가능여부: " + (available ? "O" : "X") ;
    }


}

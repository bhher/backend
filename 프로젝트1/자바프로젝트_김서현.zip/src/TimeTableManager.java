import java.sql.Time;
import java.util.ArrayList;
import java.util.Scanner;

public class TimeTableManager {

    private static final ArrayList<TimeTable> timeList = new ArrayList<>();

    public TimeTableManager(){

        TimeTable t1 = new TimeTable("12:00");
        TimeTable t2 = new TimeTable("13:00");
        TimeTable t3 = new TimeTable("14:00");
        TimeTable t4 = new TimeTable("17:00");
        TimeTable t5 = new TimeTable("18:00");
        TimeTable t6 = new TimeTable("19:00");
        TimeTable t7 = new TimeTable("20:00");

        timeList.add(t1);
        timeList.add(t2);
        timeList.add(t3);
        timeList.add(t4);
        timeList.add(t5);
        timeList.add(t6);
        timeList.add(t7);
    }

    public void printList() {
        for(int i=0; i<timeList.size(); i++){
            System.out.println(i+1+") "+timeList.get(i));
        }
    }
    public ArrayList<TimeTable> getTimeList() {
        return timeList;
    }


}

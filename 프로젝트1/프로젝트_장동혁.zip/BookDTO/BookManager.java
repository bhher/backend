package a1201.BookDTO;

import java.util.ArrayList;
import java.util.List;

public class BookManager {
    private List<BookReader> bookreaders = new ArrayList<>();
    private int bookId = 1;

    public void listBookreaders() {
        if (bookreaders.isEmpty()) {
            System.out.println("책이 없습니다.");
        } else {
            for (BookReader bookreader : bookreaders) {
                System.out.println(bookreader);
            }
        }
    }
    //책목록
    public void showBookReader() {
        for (BookReader bookreader : bookreaders) {
            System.out.println("ID: " + bookreader.getId() +"책 제목: " + bookreader.getName() + "책 저자: " + bookreader.getAuthor() + "출판연도: " + bookreader.getYear());
        }
    }
    //책입력
    public void addBookReader(String name, String author, double year) {
        BookReader bookreader = new BookReader(bookId, name, author, year);
        bookreaders.add(bookreader);
        bookId++;
        System.out.println("책 추가: " + bookreaders);
    }
    //책삭제
    public void deleteBookReader(String name) {
        BookReader toRemove = null;
        for (BookReader bookreader : bookreaders) {
            if (bookreader.getId() == bookId) {
                toRemove = bookreader;
                break;
            }
        }
        if (toRemove != null) {
            bookreaders.remove(toRemove);
            System.out.println("도서 삭제: " + toRemove);
        }else {
            System.out.println("도서를 찾을 수 없습니다.");
        }
    }
    public void updateBookReader(String uname) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'updateBookReader'");
    }

    


}

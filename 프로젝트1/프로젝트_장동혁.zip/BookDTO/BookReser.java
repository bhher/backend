package a1201.BookDTO;

import java.util.Scanner;

// import a1201.BookReser.BookManager;

public class BookReser {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BookManager manager = new BookManager();//숙소관리 객체
        boolean flag = true;
        while (flag) {
            System.out.println("\n 도서 등록 시스템.");
            System.out.println("1. 도서 추가"); 
            System.out.println("2. 도서 삭제"); 
            System.out.println("3. 도서 수정");
            System.out.println("4. 도서 조회");
            System.out.println("5. 종료"); 
            System.out.print("원하는 작업을 선택하세요 > ");
            int choice = sc.nextInt();
            sc.nextLine(); //메모리에 있는 개행문자 삭제

            switch (choice) {
                case 1:
                    System.out.print("추가하려는 책의 제목");
                    String newName = sc.nextLine();
                    System.out.print("책의 저자>>");
                    String newAuthor = sc.nextLine();
                    System.out.print("출판 연도");
                    Double newYear = sc.nextDouble();
                    sc. nextLine(); //개행문자 초기화 
                    System.out.println(newName + "추가하려는 책의 제목");
                    if(newName.equals("")){ //책이름이 입력되어 있지않으면 재입력받기
                        System.out.print("추가하려는 책의 제목 입력 \n 책의 제목>>");
                        newName = sc.nextLine();
                    }
                    manager.addBookReader(newName, newAuthor, newYear);
                    System.out.println("도서 추가 완료");
                    break;
                case 2:
                    System.out.println("삭제시작");
                    System.out.print("삭제하려는 책의 제목: ");
                    String dname = sc.nextLine();
                    if(dname.equals("")){
                        System.out.print("삭제하려는 잭의 제목 재입력 \n 이름>>");
                        dname = sc.nextLine();
                    }    
                    manager.deleteBookReader(dname);
                    System.out.println("삭제끝");
                    break;
                case 3:
                    System.out.println("수정 시작");
                    System.out.print("수정하려는 책의 이름:");
                    String uname = sc.nextLine();
                    System.out.println(uname);  
                    if (uname.equals("")) {
                        System.out.print("수정하려는 책의 이름. \nname>>");
                        newName = sc.nextLine();
                    }
                    manager.updateBookReader(uname);
                    System.out.println("수정 끝");
                    break;
                case 4:
                    System.out.println("조회 시작 \n 책의 제목 입력>>");
                    String sname = sc.nextLine();
                    if (sname.equals("")) {
                        System.out.print("조회하려는 책의 제목을 입력하세요. \nname>>");
                        newName = sc.nextLine();
                    } 
                    manager.showBookReader();
                    System.out.println("조회 끝");
                    break;  
                case 5:
                    System.out.println("종료");
                    flag = false;
                    sc.close();
                    System.exit(0); 
                    break;
                default:
                    System.out.println("다시입력하세요");
                    break;
            }
        }
        
        
    }
}
